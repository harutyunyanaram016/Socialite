<?php
/**
 * Created by PhpStorm.
 * User: gex
 * Date: 17.08.17
 * Time: 12:09
 */

namespace Cms\Controller;

class ErrorController extends CmsController
{

    public function page404()
    {
        header('Location:/ ');
    }

}