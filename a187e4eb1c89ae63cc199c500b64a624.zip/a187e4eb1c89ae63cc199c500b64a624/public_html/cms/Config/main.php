<?php

return [
    'baseUrl'        => 'http://' . $_SERVER['HTTP_HOST'],
    'defaultLang'     => 'english',
    'defaultTimezone' => 'America/Chicago',
    'defaultTheme'    => 'default'
];
