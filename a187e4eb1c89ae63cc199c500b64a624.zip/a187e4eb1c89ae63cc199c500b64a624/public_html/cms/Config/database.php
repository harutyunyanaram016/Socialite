<?php

return [
    'host' => 'localhost',
    'db_name' => 'blessey0_book',
    'username' => 'blessey0_book',
    'password' => 'blessey0_book',
    'charset' => 'utf8'
];
