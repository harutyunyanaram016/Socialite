<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('ROOT_DIR', __DIR__);
define('DS', DIRECTORY_SEPARATOR);

define('ENV', 'Cms');


require_once 'engine/Bootstrap.php';
