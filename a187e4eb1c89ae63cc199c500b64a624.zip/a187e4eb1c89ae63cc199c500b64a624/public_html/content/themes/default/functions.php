<?php
// Add css files
//Asset::css('vendor/bootstrap/css/bootstrap.min');
//Asset::css('css/clean-blog.min');
//Asset::css('vendor/font-awesome/css/font-awesome.min');

Asset::css('Assets/css/bootstrap.min');
Asset::css('Assets/css/bootstrap_min');
Asset::css('Assets/css/dashboard');
Asset::css('Assets/css/style');
Asset::css('css/style');

//Asset::js('Assets/js/bootstrap.min');
//Asset::js('Assets/js/jquery-2.0.3');
//Asset::js('Assets/js/jquery-2.0.3.min');
//Asset::js('//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min');
//Asset::js('Assets/js/bootstrap.min');
Asset::js('Assets/js/bookmarks');
Asset::js('Assets/js/user');
Asset::js('Assets/js/init');
Asset::js('Assets/js/jquery-sortable');
Asset::js('/js/script');






