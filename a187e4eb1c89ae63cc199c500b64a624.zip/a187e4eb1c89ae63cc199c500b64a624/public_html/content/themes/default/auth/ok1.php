<?php


$client_id_ok= '1256851456'; // Application ID
$public_key_ok = 'CBAJALOLEBABABABA'; // Публичный ключ приложения
$client_secret_ok = 'ED209602751FD918A6B282E3'; // Секретный ключ приложения
$redirect_uri_ok = 'http://blaweb.loc/'; // Ссылка на приложение

$url_ok = 'http://www.odnoklassniki.ru/oauth/authorize';

$params_ok = array(
    'client_id'     => $client_id_ok,
    'response_type' => 'code',
    'redirect_uri'  => $redirect_uri_ok
);

//=======================
