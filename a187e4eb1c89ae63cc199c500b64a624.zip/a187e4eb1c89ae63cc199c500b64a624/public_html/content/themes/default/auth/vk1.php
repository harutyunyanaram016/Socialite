<?php

$client_id_vk = '6223444'; // ID приложения
$client_secret_vk = 'J2DZorqGNiqrdFDI3Ikt'; // Защищённый ключ
$redirect_uri_vk = 'http://blaweb.loc/'; // Адрес сайта

$url_vk = 'http://oauth.vk.com/authorize';

$parameters = array(
    'client_id'     => $client_id_vk,
    'redirect_uri'  => $redirect_uri_vk,
    'response_type' => 'code'
);

//============
