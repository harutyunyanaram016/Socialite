<?php

$client_id_fb = '1943234859261350'; // Client ID
$client_secret_fb = 'c816abe8f10b4b32d7d1f106b272e9af'; // Client secret
$redirect_uri_fb = 'http://blaweb.loc/'; // Redirect URIs
$token_fb = 'https://graph.facebook.com/oauth/access_token';
$get_data_fb = "https://graph.facebook.com/me";

$url_fb = 'https://www.facebook.com/dialog/oauth';

$params_fb = array(
    'client_id' => $client_id_fb,
    'redirect_uri' => $redirect_uri_fb,
    'response_type' => 'code',
);

//$path = $url_fb."?"."client_id=".$client_id_fb."&redirect_uri=".urlencode($redirect_uri_fb)."&response_type=code";

