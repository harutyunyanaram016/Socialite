/**
 * Created by gex on 26.09.17.
 */

function myReloadFunction() {
    location.reload();
}

$(".bav .list-group-item").width($(".cat-list-button").width()-2);
$(".list-group-item").each(function(index, value) {
    var parent_id = value.getAttribute('parent');
    var id = value.getAttribute('data-id')
    if(parent_id != '-'){
        var html = $(".cat-item-"+id)
        $(".cat-item-"+id).remove()
        // var allHtml = $("#catItems-"+parent_id).html() + html
        $("#catItems-"+parent_id).append(html);
    }

});

// $(".cat-link").click(function(){
//     var id = $(this).attr('data-id');
//     $.ajax({
//         url: '/',
//         type: 'POST',
//         data: {id:id},
//         success: function(result){
//             console.log(result);
//         }
//     });
// })

$(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });

// $("#catItems")
//     var one = $('.one').html(),
//     two = $('.two').html();
//     $('.one').html('')
//     $('.two').html(one + '<br>' + two)
//
    var one = $('[data-par]');
        // two = document.querySelector('.two');

    // two.innerHTML = one.innerHTML + two.innerHTML;
    // one.innerHTML = '';

});

function passConfirm() {

    if (document.getElementById('sPass').value != document.getElementById('sRePass').value) {
        window.alert("Passwords are not the same.");
        return false;
    }
    return true;

}

$('#contrast-cat').on('input', function() {
    $('#contrastFilterCat').css('opacity', $(this).val());
});
$('#contrast-book').on('input', function() {
    $('#contrastFilterBook').css('opacity', $(this).val());
});




$("#menu").mousedown(function(){
    $(this).toggleClass("closed");
//        $(.menu).toggleClass("closed");

    if($(this).hasClass("closed")) {
        $(".main.button").text("Close");
        $(".menu").toggleClass("closed");
    } else {
        $(".main.button").text("Menu");
        $(".menu").toggleClass("closed");

    }
});
