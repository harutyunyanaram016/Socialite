<?php

namespace Engine\Core\Auth;

interface AuthInterface
{}