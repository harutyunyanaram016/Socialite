<?php
namespace Engine\Helper;

/**
 * Class Lang
 * @package Engine\Helper
 */
class Lang
{
    public static function e()
    {
        //$language = HelperDI::get()->get('language');
    }

    /**
     * @param string $section
     * @param string $key
     * @return void
     */
    public static function _e($section, $key)
    {

//        print_r($key);exit;

        $lang_check = \User::getCookie('language');

        $dir    = ROOT_DIR.'/cms/Language';
        $langs = scandir($dir);
        array_shift($langs);
        array_shift($langs);

//        print_r($langs);exit;
        foreach ($langs as $lang){
            if($lang_check == $lang){
                $language = $lang;
                print_r( $language);exit;
                $dir_lang  = ROOT_DIR.'/cms/Language/'.$lang;
                $langs_folder = scandir($dir_lang);
                array_shift($langs_folder);
                array_shift($langs_folder);
//                print_r($langs_folder);exit;
                foreach ($langs_folder as $land_section) {
                    if ($section == $land_section) {
                        echo isset($language->{$section}[$key]) ? $language->{$section}[$key] : '';
                    }
                }
            }
        }
    }
}
